// Servidor principal de ASTIE DIESEL — Etapa 3.
//
// Arranca:
//   node src/server.js          → producción (puerto 3001)
//   node --watch src/server.js  → desarrollo con recarga automática
//
// Variables de entorno:
//   PORT    número de puerto (default 3001)
//   DB_PATH ruta del archivo SQLite (default ./data/astie.db)
//   ORIGIN  origen(es) permitidos para CORS, separados por comas (default *)
//   ADMIN_PASSWORD / SELLER_PASSWORD  contraseñas maestras fijas, aplicadas en cada arranque (ver masterPasswords.js)
//   SETUP_KEY    si se define, la configuración inicial exige esta clave (recomendado al desplegar)
//   TRUST_PROXY  proxies de confianza para leer la IP real (default "loopback": Caddy/nginx en el mismo equipo)

"use strict";

require("./loadEnv"); // server/.env (opcional) antes de leer cualquier variable

const http = require("http");
const express = require("express");
const cors = require("cors");

// ── Importar módulos propios ANTES de usarlos ──────────────────────────────────
const events = require("./events");
const { db, setEventBus } = require("./db/database");

// Conectar el bus de eventos al módulo de DB
setEventBus(events);

// ── Rutas ──────────────────────────────────────────────────────────────────────
const authRouter    = require("./routes/auth");
const entitiesRouter = require("./routes/entities");
const backupRouter  = require("./routes/backup");

// ── App Express ────────────────────────────────────────────────────────────────
const app = express();

// Para limitar intentos por IP hay que conocer la IP real del cliente. Detrás de Caddy/nginx en el mismo
// equipo (loopback) se lee de X-Forwarded-For; con TRUST_PROXY=0 se desactiva.
const TRUST_PROXY = process.env.TRUST_PROXY ?? "loopback";
app.set("trust proxy", /^\d+$/.test(TRUST_PROXY) ? Number(TRUST_PROXY) : TRUST_PROXY);

// ORIGIN acepta una lista separada por comas (ej. "https://tienda.com,http://localhost").
// La app Android se sirve desde http://localhost.
const ORIGIN = process.env.ORIGIN
  ? process.env.ORIGIN.split(",").map((s) => s.trim()).filter(Boolean)
  : "*";

app.use(cors({
  origin: ORIGIN,
  methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "x-astie-role", "x-astie-id", "x-astie-token"],
}));

app.use(express.json({ limit: "10mb" }));

// ── Health check ───────────────────────────────────────────────────────────────
app.get("/health", (_req, res) => {
  res.json({ ok: true, ts: new Date().toISOString() });
});

// ── Rutas de la API ────────────────────────────────────────────────────────────
app.use("/api/auth",   authRouter);
app.use("/api/backup", backupRouter);
app.use("/api",        entitiesRouter);

// ── Manejo de errores ──────────────────────────────────────────────────────────
// eslint-disable-next-line no-unused-vars
app.use((err, _req, res, _next) => {
  const status = err.status || 500;
  const message = err.message || "Error interno del servidor";
  if (status >= 500) console.error("[server]", err);
  res.status(status).json({ error: message });
});

// ── Arrancar ───────────────────────────────────────────────────────────────────
const PORT = Number(process.env.PORT) || 3001;
const server = http.createServer(app);

// Limpieza de sesiones caducadas (al arrancar y cada hora)
const sessions = require("./sessions");
sessions.purgeExpired();
setInterval(() => sessions.purgeExpired(), 60 * 60 * 1000).unref();

// WebSocket sobre el mismo puerto HTTP
events.attachToServer(server);

const { syncMasterPasswords } = require("./masterPasswords");

syncMasterPasswords()
  .catch((err) => { console.error(`[server] ERROR en las contraseñas maestras: ${err.message}`); process.exit(1); })
  .then(() => server.listen(PORT, () => {
  console.log(`[server] ASTIE DIESEL backend escuchando en http://localhost:${PORT}`);
  console.log(`[server] WebSocket en ws://localhost:${PORT}/ws`);
  console.log(`[server] Health check: http://localhost:${PORT}/health`);
  if (!process.env.SETUP_KEY && !(process.env.ADMIN_PASSWORD && process.env.SELLER_PASSWORD)) {
    console.warn("[server] AVISO: sin SETUP_KEY, quien llegue primero puede hacer la configuración inicial. Defínela antes de exponer el servidor.");
  }
}));

module.exports = app; // útil para tests
