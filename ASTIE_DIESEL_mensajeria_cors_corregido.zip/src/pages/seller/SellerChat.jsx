import React from "react";
import QuoteList from "@/pages/admin/QuoteList";

// Bandeja de mensajes del vendedor. Cada conversación está asociada a una cotización
// y se abre en /seller/chat/:id, donde vive el chat existente.
export default function SellerChat() {
  return <QuoteList title="Mensajes" basePath="/seller/chat" />;
}
