#!/usr/bin/env node
// Falla si la URL del backend de un modo de build sigue siendo la de ejemplo.
//   node scripts/check-api-url.mjs webview      → revisa .env.webview (o VITE_API_URL del entorno)
//
// Un APK compilado con https://api.tudominio.com abre pero no encuentra el servidor.

import { existsSync, readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const mode = process.argv[2] || "production";

let url = process.env.VITE_API_URL;
if (!url) {
  const file = join(root, `.env.${mode}`);
  if (existsSync(file)) {
    const m = readFileSync(file, "utf8").match(/^\s*VITE_API_URL\s*=\s*(.+?)\s*$/m);
    if (m) url = m[1].replace(/^['"]|['"]$/g, "");
  }
}

if (!url) {
  console.error(`[check] ERROR: falta VITE_API_URL para el modo "${mode}" (.env.${mode}).`);
  process.exit(1);
}
if (/tudominio|example\.(com|org)/i.test(url)) {
  console.error(`[check] ERROR: VITE_API_URL sigue siendo la URL de ejemplo (${url}).`);
  console.error(`[check] Edita .env.${mode} con la URL real de tu backend, o ejecuta: VITE_API_URL=https://... npm run build:${mode}`);
  process.exit(1);
}
console.log(`[check] Backend: ${url}`);
