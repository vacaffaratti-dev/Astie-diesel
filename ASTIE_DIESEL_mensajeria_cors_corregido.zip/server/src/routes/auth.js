// Rutas de autenticación y configuración inicial.
//
// GET  /api/auth/setup-done       → { done, needs_key }  ¿está configurada la app? ¿exige clave de instalación?
// POST /api/auth/setup            → primera configuración (contraseñas + nombre tienda)
// POST /api/auth/verify           → contraseña maestra (admin/seller) → { ok, role, name, token }
// POST /api/auth/logout           → cierra la sesión del token enviado
// POST /api/auth/change-password  → cambia una contraseña maestra (solo admin)
// POST /api/auth/customer         → registro / acceso de cliente con teléfono + PIN → { customer, created, token }
// POST /api/auth/customer-pin     → el administrador restablece el PIN de un cliente
//
// Protección contra fuerza bruta: verify, customer y setup limitan los intentos fallidos por IP
// (y por IP + teléfono en clientes). Detrás de un proxy (Caddy) ver TRUST_PROXY en server.js.

"use strict";

const { Router } = require("express");
const { db } = require("../db/database");
const { requireRole, verifyMasterPassword } = require("../middleware/auth");
const { createLimiter } = require("../middleware/rateLimit");
const { hashPassword, safeEqual } = require("../passwords");
const sessions = require("../sessions");
const customerAuth = require("../customerAuth");
const { isManaged } = require("../masterPasswords");

const router = Router();

const MIN_PASSWORD = 6;
const WINDOW = 15 * 60_000;

const staffLimiter = createLimiter({ windowMs: WINDOW, max: 10 });
const customerLimiter = createLimiter({ windowMs: WINDOW, max: 8 });
const customerIpLimiter = createLimiter({ windowMs: WINDOW, max: 40 });
const setupLimiter = createLimiter({ windowMs: WINDOW, max: 5 });

// Con SETUP_KEY definida, la configuración inicial exige esa clave (evita que un extraño se adelante).
const setupKey = () => (process.env.SETUP_KEY || "").trim();

async function getSettings() {
  const list = await db.entities.AppSettings.list();
  return list[0] || null;
}

function sendError(res, next, err) {
  if (err.status === 429 && err.retryAfter) res.set("Retry-After", String(err.retryAfter));
  if (err.status && err.status < 500) return res.status(err.status).json({ error: err.message });
  return next(err);
}

// ── ¿Configurada? ─────────────────────────────────────────────────────────────
router.get("/setup-done", async (_req, res, next) => {
  try {
    const s = await getSettings();
    res.json({
      done: Boolean(s?.admin_password_hash && s?.seller_password_hash),
      needs_key: Boolean(setupKey()),
    });
  } catch (err) { next(err); }
});

// ── Setup inicial ─────────────────────────────────────────────────────────────
// Solo se permite una vez (mientras no haya contraseñas configuradas).
router.post("/setup", async (req, res, next) => {
  const ipKey = req.ip;
  try {
    setupLimiter.assertAllowed(ipKey);
    const { admin, seller, storeName = "ASTIE DIESEL", setupKey: given } = req.body || {};

    const s = await getSettings();
    if (s?.admin_password_hash) {
      return res.status(409).json({ error: "La app ya está configurada" });
    }
    if (setupKey() && !safeEqual(given ?? "", setupKey())) {
      setupLimiter.fail(ipKey);
      return res.status(403).json({ error: "Clave de instalación incorrecta" });
    }
    if (!admin || !seller) {
      return res.status(422).json({ error: "Se requieren contraseñas para admin y seller" });
    }
    if (String(admin).length < MIN_PASSWORD || String(seller).length < MIN_PASSWORD) {
      return res.status(422).json({ error: `Las contraseñas deben tener al menos ${MIN_PASSWORD} caracteres` });
    }
    const data = {
      store_name: storeName,
      admin_password_hash: await hashPassword(admin),
      seller_password_hash: await hashPassword(seller),
    };
    const result = s
      ? await db.entities.AppSettings.update(s.id, data)
      : await db.entities.AppSettings.create(data);
    res.status(201).json({ ok: true, store_name: result.store_name });
  } catch (err) { sendError(res, next, err); }
});

// ── Verificar contraseña maestra (admin / seller) ─────────────────────────────
// Devuelve { ok, role, name, token } o 401. El token es el que se envía luego en x-astie-token.
router.post("/verify", async (req, res, next) => {
  const key = req.ip;
  try {
    staffLimiter.assertAllowed(key);
    const { role, password } = req.body || {};
    if (!["admin", "seller"].includes(role) || !password) {
      return res.status(422).json({ error: "Faltan role o password" });
    }
    if (!(await verifyMasterPassword(role, password))) {
      staffLimiter.fail(key);
      return res.status(401).json({ error: "Contraseña incorrecta" });
    }
    staffLimiter.clear(key);
    sessions.purgeExpired();
    res.json({ ok: true, role, name: role === "admin" ? "Administrador" : "Vendedor", token: sessions.create(role) });
  } catch (err) { sendError(res, next, err); }
});

// ── Cerrar sesión ─────────────────────────────────────────────────────────────
router.post("/logout", (req, res) => {
  const token = req.headers["x-astie-token"];
  if (typeof token === "string" && token) sessions.revoke(token);
  res.json({ ok: true });
});

// ── Cambiar contraseña maestra (solo admin) ───────────────────────────────────
// Cierra las sesiones abiertas de ese rol (salvo la del administrador que hace el cambio).
router.post("/change-password", requireRole("admin"), async (req, res, next) => {
  try {
    const { role, newPassword } = req.body || {};
    if (!["admin", "seller"].includes(role) || !newPassword) {
      return res.status(422).json({ error: "Faltan role o newPassword" });
    }
    if (String(newPassword).length < MIN_PASSWORD) {
      return res.status(422).json({ error: `La contraseña debe tener al menos ${MIN_PASSWORD} caracteres` });
    }
    if (isManaged(role)) {
      return res.status(409).json({ error: `Esta contraseña la define el servidor (${role === "admin" ? "ADMIN_PASSWORD" : "SELLER_PASSWORD"}); cámbiala allí` });
    }
    const s = await getSettings();
    if (!s) return res.status(503).json({ error: "App no configurada" });
    const field = role === "admin" ? "admin_password_hash" : "seller_password_hash";
    await db.entities.AppSettings.update(s.id, { [field]: await hashPassword(newPassword) });
    if (role === "admin") sessions.revokeRoleExcept("admin", req.headers["x-astie-token"]);
    else sessions.revokeRole("seller");
    res.json({ ok: true });
  } catch (err) { sendError(res, next, err); }
});

// ── Registro / acceso de cliente: teléfono + PIN ──────────────────────────────
// Si el teléfono no existe crea al cliente con el PIN elegido; si existe, exige el PIN.
router.post("/customer", async (req, res, next) => {
  const ipKey = req.ip;
  const phoneKey = `${req.ip}|${String(req.body?.phone ?? "").trim()}`;
  try {
    customerLimiter.assertAllowed(phoneKey);
    customerIpLimiter.assertAllowed(ipKey);
    let out;
    try {
      out = await customerAuth.loginOrRegister(req.body);
    } catch (err) {
      if (err.status === 401) { customerLimiter.fail(phoneKey); customerIpLimiter.fail(ipKey); }
      throw err;
    }
    customerLimiter.clear(phoneKey);
    res.status(out.created ? 201 : 200).json(out);
  } catch (err) { sendError(res, next, err); }
});

// ── Restablecer el PIN de un cliente (solo admin) ─────────────────────────────
router.post("/customer-pin", requireRole("admin"), async (req, res, next) => {
  try {
    const { customer_id, pin } = req.body || {};
    if (!customer_id || !pin) return res.status(422).json({ error: "Faltan customer_id o pin" });
    await customerAuth.resetPin(customer_id, pin);
    res.json({ ok: true });
  } catch (err) { sendError(res, next, err); }
});

module.exports = router;
