// Sesiones con token aleatorio.
//
// Al iniciar sesión el servidor entrega un token de 256 bits y guarda solo su hash SHA-256 en SQLite
// (tabla `sessions`), así una copia de la base de datos no revela tokens utilizables. Las sesiones
// sobreviven a los reinicios del servidor y caducan solas:
//   · admin / vendedor: 12 horas
//   · cliente:          90 días (la app Android mantiene la sesión abierta)
//
// Así la contraseña maestra ya no viaja en cada petición: solo en el inicio de sesión.

"use strict";

const crypto = require("crypto");
const { db } = require("./db/database");

const TTL_MS = {
  admin: 12 * 60 * 60 * 1000,
  seller: 12 * 60 * 60 * 1000,
  customer: 90 * 24 * 60 * 60 * 1000,
};

const hashToken = (token) => crypto.createHash("sha256").update(String(token)).digest("hex");

function create(role, customerId = null) {
  if (!TTL_MS[role]) throw new Error(`Rol desconocido: ${role}`);
  const token = crypto.randomBytes(32).toString("base64url");
  const now = Date.now();
  db.raw
    .prepare("INSERT INTO sessions (token_hash, role, customer_id, expires_at, created_at) VALUES (?, ?, ?, ?, ?)")
    .run(hashToken(token), role, customerId, now + TTL_MS[role], now);
  return token;
}

// → { role, customer_id } o null si el token no existe o caducó
function lookup(token) {
  if (typeof token !== "string" || !token) return null;
  const row = db.raw
    .prepare("SELECT role, customer_id, expires_at FROM sessions WHERE token_hash = ?")
    .get(hashToken(token));
  if (!row) return null;
  if (row.expires_at <= Date.now()) {
    db.raw.prepare("DELETE FROM sessions WHERE token_hash = ?").run(hashToken(token));
    return null;
  }
  return { role: row.role, customer_id: row.customer_id };
}

const revoke = (token) => db.raw.prepare("DELETE FROM sessions WHERE token_hash = ?").run(hashToken(token));
const revokeRole = (role) => db.raw.prepare("DELETE FROM sessions WHERE role = ?").run(role);
const revokeRoleExcept = (role, token) =>
  db.raw.prepare("DELETE FROM sessions WHERE role = ? AND token_hash != ?").run(role, hashToken(token));
const revokeCustomer = (customerId) => db.raw.prepare("DELETE FROM sessions WHERE customer_id = ?").run(customerId);
const purgeExpired = () => db.raw.prepare("DELETE FROM sessions WHERE expires_at <= ?").run(Date.now());

module.exports = { create, lookup, revoke, revokeRole, revokeRoleExcept, revokeCustomer, purgeExpired };
