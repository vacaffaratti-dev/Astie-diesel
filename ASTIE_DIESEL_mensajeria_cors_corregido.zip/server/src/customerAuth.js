// Registro e inicio de sesión de clientes (teléfono + PIN).
//
// Antes el teléfono bastaba para entrar: cualquiera que lo conociera veía los datos del cliente y sus
// cotizaciones. Ahora cada cliente tiene un PIN (hash PBKDF2 en `customer_credentials`) y recibe un
// token de sesión aleatorio.
//
// Clientes anteriores a esta versión no tienen PIN: la primera vez que entran deben repetir su nombre y
// apellido tal como los registraron y elegir un PIN. El administrador puede restablecerlo (resetPin).

"use strict";

const { db } = require("./db/database");
const { hashPassword, checkPassword } = require("./passwords");
const sessions = require("./sessions");

const MIN_PIN = 4;
const MAX_PIN = 64;

function httpError(status, message) {
  const err = new Error(message);
  err.status = status;
  return err;
}

const norm = (s) => String(s ?? "").trim().toLowerCase();

function assertPin(pin) {
  const p = String(pin ?? "");
  if (p.length < MIN_PIN) throw httpError(422, `El PIN debe tener al menos ${MIN_PIN} caracteres`);
  if (p.length > MAX_PIN) throw httpError(422, "El PIN es demasiado largo");
  return p;
}

function saveCredential(customerId, pinHash) {
  const ts = new Date().toISOString();
  db.raw
    .prepare(
      `INSERT INTO customer_credentials (customer_id, pin_hash, created_date, updated_date) VALUES (?, ?, ?, ?)
       ON CONFLICT(customer_id) DO UPDATE SET pin_hash = excluded.pin_hash, updated_date = excluded.updated_date`,
    )
    .run(customerId, pinHash, ts, ts);
}

// → { customer, created, token }.  Lanza 401 si el PIN (o, en clientes antiguos, el nombre) no coincide.
async function loginOrRegister(body = {}) {
  const { full_name, last_name, email, address } = body;
  const phone = String(body.phone ?? "").trim();
  if (!full_name || !last_name || !phone) throw httpError(422, "Faltan full_name, last_name o phone");
  const pin = assertPin(body.pin);

  const existing = (await db.entities.Customer.filter({ phone }))[0];

  if (!existing) {
    const customer = await db.entities.Customer.create({ full_name, last_name, phone, email: email ?? null, address: address ?? null });
    saveCredential(customer.id, await hashPassword(pin));
    return { customer, created: true, token: sessions.create("customer", customer.id) };
  }

  const cred = db.raw.prepare("SELECT pin_hash FROM customer_credentials WHERE customer_id = ?").get(existing.id);
  const bad = () => httpError(401, "Teléfono o PIN incorrecto");

  if (cred) {
    if (!(await checkPassword(pin, cred.pin_hash))) throw bad();
  } else {
    // Cliente anterior a los PIN: se reclama con nombre y apellido y se fija el PIN elegido
    if (norm(full_name) !== norm(existing.full_name) || norm(last_name) !== norm(existing.last_name)) throw bad();
    saveCredential(existing.id, await hashPassword(pin));
  }

  return { customer: existing, created: false, token: sessions.create("customer", existing.id) };
}

// El administrador fija un PIN nuevo (cliente que lo olvidó). Cierra sus sesiones abiertas.
async function resetPin(customerId, pin) {
  await db.entities.Customer.get(customerId); // 404 si no existe
  saveCredential(customerId, await hashPassword(assertPin(pin)));
  sessions.revokeCustomer(customerId);
}

module.exports = { loginOrRegister, resetPin, MIN_PIN };
