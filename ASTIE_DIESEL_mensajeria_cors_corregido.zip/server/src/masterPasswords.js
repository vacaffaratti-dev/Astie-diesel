// Contraseñas maestras fijas.
//
// Si defines ADMIN_PASSWORD y/o SELLER_PASSWORD (variables de entorno o archivo server/.env), el servidor
// las aplica en cada arranque: son la fuente de verdad y quedan siempre iguales, aunque se borre la base
// de datos. Con ambas definidas la pantalla de «Configuración inicial» ya no aparece.
//
// Si una contraseña cambió respecto a la guardada, se actualiza y se cierran las sesiones de ese rol.
// Mientras la variable exista, la contraseña no se puede cambiar desde la app (ver routes/auth.js).

"use strict";

const { db } = require("./db/database");
const { hashPassword, checkPassword } = require("./passwords");
const sessions = require("./sessions");

const MIN_PASSWORD = 6;
const VARS = { admin: "ADMIN_PASSWORD", seller: "SELLER_PASSWORD" };
const FIELDS = { admin: "admin_password_hash", seller: "seller_password_hash" };

// ¿Esta contraseña la define el servidor?
const isManaged = (role) => Boolean((process.env[VARS[role]] || "").length);

async function syncMasterPasswords(log = console) {
  const wanted = {};
  for (const role of Object.keys(VARS)) {
    const value = process.env[VARS[role]];
    if (!value) continue;
    if (value.length < MIN_PASSWORD) {
      throw new Error(`${VARS[role]} debe tener al menos ${MIN_PASSWORD} caracteres`);
    }
    wanted[role] = value;
  }
  if (!Object.keys(wanted).length) return;
  if (wanted.admin && wanted.seller && wanted.admin === wanted.seller) {
    throw new Error("ADMIN_PASSWORD y SELLER_PASSWORD deben ser distintas");
  }

  const settings = (await db.entities.AppSettings.list())[0] || null;
  const changes = {};
  for (const [role, value] of Object.entries(wanted)) {
    if (!settings || !(await checkPassword(value, settings[FIELDS[role]]))) {
      changes[FIELDS[role]] = await hashPassword(value);
      changes[`_role_${role}`] = true;
    }
  }
  if (!Object.keys(changes).length) return log.log("[server] Contraseñas maestras: ya coinciden con el entorno");

  const roles = Object.keys(changes).filter((k) => k.startsWith("_role_")).map((k) => k.slice(6));
  const data = Object.fromEntries(Object.entries(changes).filter(([k]) => !k.startsWith("_role_")));
  if (settings) await db.entities.AppSettings.update(settings.id, data);
  else await db.entities.AppSettings.create(data);
  roles.forEach((r) => sessions.revokeRole(r));
  log.log(`[server] Contraseñas maestras aplicadas desde el entorno: ${roles.join(", ")}`);
}

module.exports = { syncMasterPasswords, isManaged };
