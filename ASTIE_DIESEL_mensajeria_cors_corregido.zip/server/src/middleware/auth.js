// Middleware de autenticación.
//
// Admin y vendedores inician sesión con una contraseña maestra (hash PBKDF2 en AppSettings) y los clientes
// con teléfono + PIN. En los dos casos el servidor entrega un TOKEN de sesión aleatorio (ver sessions.js)
// y las peticiones siguientes llevan estos headers:
//
//   x-astie-role:  "admin" | "seller" | "customer"
//   x-astie-token: token de sesión (NO la contraseña)
//   x-astie-id:    id del cliente (solo para el rol "customer"; debe coincidir con el dueño del token)
//
// Usa HTTPS fuera de una red de confianza: el token (y la contraseña, al iniciar sesión) viajan en los headers.

"use strict";

const { db } = require("../db/database");
const sessions = require("../sessions");
const { checkPassword } = require("../passwords");

async function getSettings() {
  const list = await db.entities.AppSettings.list();
  return list[0] || null;
}

function authError(status, message) {
  const err = new Error(message);
  err.status = status;
  return err;
}

// Comprueba la contraseña maestra (solo en el inicio de sesión). → true / false
async function verifyMasterPassword(role, password) {
  const settings = await getSettings();
  if (!settings) throw authError(503, "App no configurada");
  const field = role === "admin" ? "admin_password_hash" : "seller_password_hash";
  return checkPassword(password, settings[field]);
}

// Verifica el token de sesión y devuelve la identidad { role, id | name }.
// Lanza un error con .status (401/403) si no es válida.
// La usan requireRole (headers HTTP) y el WebSocket (mensaje "auth").
async function authenticate(role, token, id) {
  if (role !== "admin" && role !== "seller" && role !== "customer") throw authError(403, "Rol no autorizado");
  if (typeof token !== "string" || !token) throw authError(401, "Falta x-astie-token");

  const session = sessions.lookup(token);
  if (!session || session.role !== role) throw authError(401, "Sesión inválida o caducada");

  if (role === "customer") {
    if (typeof id !== "string" || !id || session.customer_id !== id) throw authError(401, "Sesión inválida o caducada");
    try {
      await db.entities.Customer.get(id);
    } catch {
      throw authError(401, "Cliente no encontrado");
    }
    return { role, id };
  }

  return { role, name: role === "admin" ? "Administrador" : "Vendedor" };
}

// requireRole(roles) → middleware que verifica que el rol esté en la lista.
// roles: string | string[]  Ej: "admin"  o  ["admin", "seller"]
function requireRole(roles) {
  const allowed = Array.isArray(roles) ? roles : [roles];

  return async (req, res, next) => {
    const role = req.headers["x-astie-role"];

    if (!allowed.includes(role)) {
      return res.status(403).json({ error: "Rol no autorizado" });
    }

    try {
      req.astie = await authenticate(role, req.headers["x-astie-token"], req.headers["x-astie-id"]);
    } catch (err) {
      return res.status(err.status || 500).json({ error: err.message });
    }
    next();
  };
}

// Middleware público (no requiere autenticación)
function publicRoute(req, _res, next) {
  req.astie = { role: "guest" };
  next();
}

module.exports = { requireRole, publicRoute, authenticate, verifyMasterPassword, checkPassword };
