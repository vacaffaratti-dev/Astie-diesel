// Límite de intentos fallidos (en memoria) para frenar la fuerza bruta contra contraseñas y PIN.
//
//   const limiter = createLimiter({ windowMs: 15 * 60_000, max: 10 });
//   limiter.assertAllowed(key);   // lanza 429 si esa clave ya agotó sus intentos
//   limiter.fail(key);            // registrar un intento fallido
//   limiter.clear(key);           // acierto: se borra el contador
//
// Se reinicia al reiniciar el servidor; para un solo proceso es suficiente.

"use strict";

function createLimiter({ windowMs, max }) {
  const entries = new Map(); // clave → { count, resetAt }

  const timer = setInterval(() => {
    const now = Date.now();
    for (const [k, v] of entries) if (v.resetAt <= now) entries.delete(k);
  }, Math.min(windowMs, 60_000));
  timer.unref?.();

  const current = (key) => {
    const e = entries.get(key);
    if (!e) return null;
    if (e.resetAt <= Date.now()) { entries.delete(key); return null; }
    return e;
  };

  return {
    assertAllowed(key) {
      const e = current(key);
      if (e && e.count >= max) {
        const err = new Error("Demasiados intentos. Espera unos minutos e inténtalo de nuevo.");
        err.status = 429;
        err.retryAfter = Math.ceil((e.resetAt - Date.now()) / 1000);
        throw err;
      }
    },
    fail(key) {
      const e = current(key);
      if (e) e.count++;
      else entries.set(key, { count: 1, resetAt: Date.now() + windowMs });
    },
    clear(key) { entries.delete(key); },
  };
}

module.exports = { createLimiter };
