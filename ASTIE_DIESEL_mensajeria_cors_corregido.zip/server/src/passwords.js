// Hash y verificación de secretos (contraseñas maestras y PIN de clientes) con PBKDF2-SHA256.
// Formato guardado:  pbkdf2$<iteraciones>$<sal base64>$<hash base64>

"use strict";

const crypto = require("crypto");

const ITERATIONS = 150_000;

function pbkdf2(secret, salt, iterations) {
  return new Promise((resolve, reject) => {
    crypto.pbkdf2(secret, salt, iterations, 32, "sha256", (err, key) => (err ? reject(err) : resolve(key)));
  });
}

async function hashPassword(secret) {
  const salt = crypto.randomBytes(16);
  const key = await pbkdf2(String(secret), salt, ITERATIONS);
  return `pbkdf2$${ITERATIONS}$${salt.toString("base64")}$${key.toString("base64")}`;
}

async function checkPassword(secret, stored) {
  const parts = String(stored || "").split("$");
  if (parts[0] !== "pbkdf2" || parts.length < 4) return false;
  const [, iterations, saltB64, hashB64] = parts;
  const expected = Buffer.from(hashB64, "base64");
  const actual = await pbkdf2(String(secret), Buffer.from(saltB64, "base64"), Number(iterations));
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

// Comparación en tiempo constante de dos textos (claves de instalación, etc.)
function safeEqual(a, b) {
  const x = crypto.createHash("sha256").update(String(a)).digest();
  const y = crypto.createHash("sha256").update(String(b)).digest();
  return crypto.timingSafeEqual(x, y);
}

module.exports = { hashPassword, checkPassword, safeEqual };
