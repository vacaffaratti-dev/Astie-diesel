# Backend (carpeta `server/`)

Servidor propio en **Node.js + SQLite + WebSocket** que guarda los datos compartidos y da el chat en tiempo real.

| Capa | Tecnología |
|---|---|
| Servidor | Express 4 |
| Base de datos | SQLite (better-sqlite3), archivo `server/data/astie.db` (se crea solo) |
| Tiempo real | WebSocket (ws) en `/ws`, mismo puerto que HTTP |
| Auth | Contraseña maestra (personal) y teléfono + PIN (clientes), PBKDF2 · token de sesión en headers `x-astie-*` |

---

## Arranque

Desde la raíz del proyecto:

```bash
npm run server:install      # una vez (better-sqlite3 se compila/descarga según tu sistema)
npm run server:dev          # desarrollo, recarga automática
npm run server              # producción
curl http://localhost:3001/health
```

Requiere Node 18 o superior.

## Variables de entorno

| Variable | Por defecto | Descripción |
|---|---|---|
| `PORT` | `3001` | Puerto HTTP/WS |
| `DB_PATH` | `server/data/astie.db` | Archivo SQLite |
| `ADMIN_PASSWORD` / `SELLER_PASSWORD` | _(vacías)_ | Contraseñas maestras **fijas**: se aplican en cada arranque, así que siempre son las mismas aunque se borre la base de datos. Con ambas definidas no aparece la configuración inicial y no se pueden cambiar desde la app. Pueden ir en el entorno o en `server/.env` (plantilla: `server/.env.example`) |
| `SETUP_KEY` | _(vacía)_ | Si se define, la configuración inicial (`/api/auth/setup`) exige esta clave. **Defínela al desplegar** |
| `TRUST_PROXY` | `loopback` | Proxies de confianza para leer la IP real (límite de intentos). Con Caddy/nginx en el mismo equipo no hace falta tocarlo; `0` lo desactiva |
| `ORIGIN` | `*` | Origen(es) CORS permitidos, separados por comas. La app Android se sirve desde `http://localhost`; ej.: `ORIGIN=https://tienda.com,http://localhost` |

---

## API REST

### Autenticación

Al iniciar sesión el servidor entrega un **token de sesión** aleatorio (se guarda solo su hash en la tabla `sessions`; las sesiones sobreviven a reinicios). Caducan a las 12 h (admin/vendedor) o a los 90 días (cliente). La contraseña maestra y el PIN solo viajan en el inicio de sesión. Cada petición lleva el token en headers:

| Header | Valor | Roles |
|---|---|---|
| `x-astie-role` | `admin` / `seller` / `customer` | todos |
| `x-astie-token` | token de sesión | todos |
| `x-astie-id` | id del cliente (debe ser el dueño del token) | customer |

```
GET  /api/auth/setup-done      → { done, needs_key }
POST /api/auth/setup           → { admin, seller, storeName, setupKey? }   (solo mientras no esté configurada)
POST /api/auth/verify          → { role, password }  →  { ok, role, name, token }
POST /api/auth/logout          → revoca el token enviado
POST /api/auth/customer        → { full_name, last_name, phone, pin, email?, address? }  →  { customer, created, token }
                                 (teléfono nuevo: crea al cliente con ese PIN; existente: exige el PIN)
POST /api/auth/customer-pin    → { customer_id, pin }   (solo admin: restablece el PIN de un cliente)
POST /api/auth/change-password → { role, newPassword }  (solo admin; cierra las demás sesiones de ese rol)
```

`verify`, `customer` y `setup` limitan los intentos fallidos por IP (429 con `Retry-After`).
Clientes creados antes de los PIN: la primera vez repiten nombre y apellido y eligen un PIN.


### Entidades

`AppSettings`, `Category`, `Subcategory`, `Product`, `Seller`, `Customer`, `Quote`, `Message`.

```
GET    /api/:entity              → lista (?sort=-campo&limit=&skip=&campo=valor)
GET    /api/:entity/:id
POST   /api/:entity
PUT    /api/:entity/:id
DELETE /api/:entity/:id
POST   /api/:entity/import       → { rows, replace }   (solo admin)
```

Filtros: `?campo=valor` (los booleanos se envían como `true`/`false`) o con operadores
`?campo[$gt]=5` (`$eq $ne $gt $gte $lt $lte $in $nin`). Los nombres de campo y de orden solo pueden ser
identificadores simples (`[A-Za-z0-9_]`); cualquier otra cosa responde 400.

### Permisos

Según el rol (`src/access.js`; las mismas reglas valen para la API REST y el WebSocket):

| Entidad | admin | vendedor | cliente |
|---|---|---|---|
| Category, Subcategory, Product | leer y escribir | leer | leer |
| Quote | todo | leer y escribir | **solo las suyas**: leer y crear (siempre quedan `pending`; el presupuesto, el vendedor y el cierre son del personal) |
| Message | todo | leer y escribir | **solo los de sus cotizaciones**: leer y escribir (siempre como cliente y nunca como presupuesto) |
| Customer | todo | leer y escribir | **solo su perfil**: leer y editar |
| Seller | todo | leer | — |
| AppSettings | todo | — | — |

Para un cliente, lo ajeno «no existe»: un listado solo devuelve lo suyo (aunque pida otro `customer_id`) y un `GET` por id de algo ajeno responde 404.
Escribir en algo ajeno, o modificar/borrar cotizaciones o mensajes, responde 403.

### Respaldo

```
GET  /api/backup                   → exporta todos los datos          [admin]
POST /api/backup/import            → importa un respaldo              [admin]
POST /api/backup/import?replace=1  → reimporta limpiando primero      [admin]
```

La pantalla **Admin → Configuración → Datos y respaldo** usa las rutas de entidades (`list` / `import`), no estas.

---

## WebSocket (chat en tiempo real)

`ws://host:3001/ws` (o `wss://` detrás de HTTPS). El frontend lo maneja en `src/api/db.js`: se conecta al iniciar sesión,
se reconecta solo y se cierra al cerrar sesión.

**Hay que autenticarse primero.** Los navegadores no pueden mandar headers en un WebSocket, así que las credenciales
van en el primer mensaje (las mismas de la API REST):

```json
{ "type": "auth", "role": "customer", "id": "…", "token": "token de sesión" }
{ "type": "auth", "role": "seller", "token": "token de sesión" }
```

Después:

```json
{ "type": "subscribe", "entity": "Message", "quoteId": "abc123" }
{ "type": "unsubscribe", "entity": "Message", "quoteId": "abc123" }
{ "type": "ping" }
```

Respuestas: `{ "type": "auth_ok" }`, `{ "type": "event", "entity": "Message", "event": { "id", "type": "create|update|delete", "data": {…} } }`,
`{ "type": "pong" }` y `{ "type": "error", "message": "…" }`.

- Sin `auth` válido en 10 s, o con credenciales incorrectas, el servidor cierra con el código **4401**.
- Solo se puede suscribir a entidades que el rol puede leer (`AppSettings`, por ejemplo, solo el admin).
- Un cliente solo recibe los eventos de sus propias cotizaciones, mensajes y perfil.

---

## Estructura

```
server/
├── src/
│   ├── db/database.js       ← acceso a SQLite; misma API que db.js del frontend
│   ├── db/schema.js         ← DDL + mapa de entidades
│   ├── middleware/auth.js   ← verificación de headers + PBKDF2
│   ├── routes/              ← auth.js · backup.js · entities.js (CRUD genérico y permisos)
│   ├── events.js            ← bus de eventos + servidor WebSocket
│   └── server.js            ← arranque
└── package.json
```

## Migrar datos existentes

Lo más simple: en la app, **Admin → Configuración → Importar** (acepta el respaldo `.json` de la app o los `.csv` de Base44,
ver `MIGRAR_DATOS_BASE44.md`). Por línea de comandos:

```bash
curl -X POST http://localhost:3001/api/backup/import \
  -H "Content-Type: application/json" \
  -H "x-astie-role: admin" -H "x-astie-token: TU_CONTRASEÑA" \
  --data-binary @respaldo.json
```

---

## Limitaciones conocidas

- **Sin `SETUP_KEY`, `/api/auth/setup` queda abierto hasta que se configura la app.** Define la variable o configura apenas despliegues.
- Todos los vendedores comparten una sola contraseña maestra (no hay cuentas individuales).
- Por `http` la contraseña, el PIN y el token viajan sin cifrar: usa HTTPS fuera de una red de confianza.
- Las credenciales del WebSocket se verifican al conectar: si una sesión se revoca (logout, cambio de contraseña, PIN restablecido), los sockets ya abiertos siguen funcionando hasta que se reconecten.
- El límite de intentos vive en memoria: se reinicia con el servidor.
